package constant

var (
	UA string
)
